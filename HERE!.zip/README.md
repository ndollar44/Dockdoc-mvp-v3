# DockDoc MVP (React Native bare)

**Purpose**: Scan/enter a dock leveler serial → show manuals, parts list, multi-vendor prices, and an instant quote.
Stack: React Native (bare) + VisionCamera + ML Kit OCR. Defaults: labor $245/hr, min 2 hrs; 15% parts markup; MI tax 6% on parts.

## Setup (brand-new project)

1) Create a new React Native app (bare):
```bash
npx react-native init DockDoc --version 0.74.3 --template react-native@0.74.3
cd DockDoc
```

2) Copy the contents of this `DockDoc-MVP/src` folder into your app's `src`, and place `App.tsx`, `tsconfig.json`, `babel.config.js`, and `package.json` fields accordingly.
   - If your init created a default `App.tsx`, replace it with the one in this repo.
   - Ensure `paths` alias `@/*` is supported by your tsconfig.

3) Install dependencies:
```bash
yarn add @react-navigation/native @react-navigation/native-stack react-native-safe-area-context react-native-screens react-native-gesture-handler react-native-reanimated react-native-vision-camera vision-camera-code-scanner vision-camera-ocr
yarn add -D typescript @types/react @types/react-native @babel/core metro-react-native-babel-preset
```

4) iOS specific:
```bash
cd ios && pod install && cd ..
```

5) Android specific:
- Ensure min SDK >= 23 and Kotlin/Gradle per VisionCamera docs.
- Add camera permission to `AndroidManifest.xml`.
- Enable `react-native-reanimated` plugin in `babel.config.js` (already included).

6) Permissions:
- iOS: Add `NSCameraUsageDescription` to `Info.plist`.
- Android: `<uses-permission android:name="android.permission.CAMERA" />`

7) Run it:
```bash
yarn ios
# or
yarn android
```

## OCR & Scanning (to implement)

- Use `react-native-vision-camera` with `vision-camera-ocr` frame processor.
- Create a Camera screen that detects text blocks and proposes the most serial-like match.
- Fallback: manual entry via `SerialInput` component.

## Data sources

- `src/data/brands.json`: brand list + serial patterns (rough placeholders).
- `src/data/manuals.json`: to be curated with links to manufacturer PDFs.
- `src/data/vendors.json`: vendor sites; use this to create search links.
- For pricing, start by manually pasting known part numbers + prices; later, add scrapers/APIs.

## Pricing defaults

- Labor: $245/hr, minimum 2 hours.
- Parts: +15% markup.
- Tax: default 6% Michigan on **parts only** (adjust in `utils/pricing.ts`).

## Roadmap

- [ ] Implement Camera OCR screen with VisionCamera
- [ ] Auto-detect brand by regex + manual mapping by model
- [ ] Scrape/manual sync for manuals.json and vendor pricing
- [ ] Add login + sync (Firebase) and offline caching
- [ ] Add diagnostic decision tree (JSON-driven)

